class ServiceDB {
    services = []

    constructor() {
        this.services.push({
            imageURL: "/images/veinclogger.jpg",
            name: "The VeinClogger",
            synopsis: "Hamburger with Quad-Beef Patty, Eggs and Bacon",
            price: "$19.99",
            noOfMeals: 2,
            isTopPkg: true,
        })
        this.services.push({
            imageURL: "/images/nugget.jpg",
            name: "Master Nugget",
            synopsis: "Split Baguettes with Chicken+Veggies+Sauce",
            price: "$16.99",
            noOfMeals: 2,
            isTopPkg: true,
        })
        this.services.push({
            imageURL: "/images/3xhamburger.jpg",
            name: "3x Hamburger",
            synopsis: "Hamburger with Beef-Chicken-Pork",
            price: "$18.99",
            noOfMeals: 2,
            isTopPkg: true,
        })
        this.services.push({
            imageURL: "/images/hotdog.jpg",
            name: "Street Dogs",
            synopsis: "Pack of Hotdogs with assorted Veggies",
            price: "$9.99",
            noOfMeals: 5,
            isTopPkg: true,
        })
        this.services.push({
            imageURL: "/images/milkshake.jpg",
            name: "Shake Package",
            synopsis: "3 Assorted Protein Milkshakes",
            price: "$10.99",
            noOfMeals: 3,
            isTopPkg: false,
        })
        this.services.push({
            imageURL: "/images/vegetables.jpg",
            name: "Veggie Salad",
            synopsis: "Assorted Veggies Pack With Special Sauce",
            price: "$15.99",
            noOfMeals: 3,
            isTopPkg: false,
        })
    }

    getServices() {
        return this.services;
    }
}

module.exports = ServiceDB;